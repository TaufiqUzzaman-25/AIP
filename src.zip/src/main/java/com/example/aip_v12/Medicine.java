package com.example.aip_v12;

public class Medicine {
    private String id; // NEW: Needed for deletion
    private String name;
    private double price;
    private int quantity = 1;

    // Primary constructor for database
    public Medicine(String id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    // Safe fallback constructor so CartManager doesn't break
    public Medicine(String name, double price) {
        this.id = "";
        this.name = name;
        this.price = price;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    @Override
    public String toString() {
        return name + " - ৳" + price;
    }
}