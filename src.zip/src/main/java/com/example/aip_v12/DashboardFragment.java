package com.example.aip_v12;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import java.util.ArrayList;

public class DashboardFragment extends Fragment {

    private LineChart weightChart;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        weightChart = view.findViewById(R.id.weightChart);
        setupChart();
        loadDummyData(); // Later, we will pull this data from Firebase!

        return view;
    }

    private void setupChart() {
        weightChart.getDescription().setEnabled(false);
        weightChart.getAxisRight().setEnabled(false);
        weightChart.setDrawGridBackground(false);

        XAxis xAxis = weightChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
    }

    private void loadDummyData() {
        ArrayList<Entry> entries = new ArrayList<>();
        // Format: Entry(X-axis time/day, Y-axis weight in kg)
        entries.add(new Entry(1f, 85.0f));
        entries.add(new Entry(2f, 84.5f));
        entries.add(new Entry(3f, 83.2f));
        entries.add(new Entry(4f, 82.8f));
        entries.add(new Entry(5f, 81.5f));

        LineDataSet dataSet = new LineDataSet(entries, "Weight (kg)");
        dataSet.setColor(Color.parseColor("#00BF6D")); // Your App's Green
        dataSet.setCircleColor(Color.parseColor("#00BF6D"));
        dataSet.setLineWidth(3f);
        dataSet.setCircleRadius(5f);
        dataSet.setDrawValues(true);

        LineData lineData = new LineData(dataSet);
        weightChart.setData(lineData);
        weightChart.invalidate(); // Refreshes the chart
    }
}