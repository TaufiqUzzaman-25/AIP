package com.example.aip_v12;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import java.util.HashMap;
import java.util.Map;

public class AdminMainActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private GoogleSignInClient mGoogleSignInClient; // Added Google Client

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_main);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Initialize Google Sign-In Client for Logout
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        CardView cardLogs = findViewById(R.id.cardLogs);
        CardView cardDoctors = findViewById(R.id.cardDoctors);
        CardView cardPharmacy = findViewById(R.id.cardPharmacy);
        CardView cardOrders = findViewById(R.id.cardOrders);
        CardView cardAddAdmin = findViewById(R.id.cardAddAdmin);
        Button btnAdminLogout = findViewById(R.id.btnAdminLogout);

        // Opens the User Activity Logs screen
        cardLogs.setOnClickListener(v ->
                startActivity(new Intent(AdminMainActivity.this, AdminViewLogsActivity.class)));

        // Opens the Add Doctor screen
        cardDoctors.setOnClickListener(v ->
                startActivity(new Intent(AdminMainActivity.this, AdminAddDoctorActivity.class)));

        // Opens the Add Medicine screen
        cardPharmacy.setOnClickListener(v ->
                startActivity(new Intent(AdminMainActivity.this, AdminAddMedicineActivity.class)));

        // Opens the E-Pharmacy Orders list
        cardOrders.setOnClickListener(v ->
                startActivity(new Intent(AdminMainActivity.this, AdminViewOrdersActivity.class)));

        // Logic to add a new admin email to Firestore
        cardAddAdmin.setOnClickListener(v -> showAddAdminDialog());

        // UPDATED LOGOUT LOGIC: Signs out of Firebase AND Google
        btnAdminLogout.setOnClickListener(v -> {
            // 1. Sign out of Firebase
            FirebaseAuth.getInstance().signOut();

            // 2. Sign out of Google to force the account picker next time
            mGoogleSignInClient.signOut().addOnCompleteListener(this, task -> {
                Intent intent = new Intent(AdminMainActivity.this, SignInActivity.class);
                // Clear the backstack so they can't press the 'back' button to re-enter
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            });
        });
    }

    private void showAddAdminDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Admin");
        builder.setMessage("Enter the email address of the new admin:");

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        builder.setView(input);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String newAdminEmail = input.getText().toString().trim().toLowerCase();
            if (!newAdminEmail.isEmpty()) {
                Map<String, Object> adminData = new HashMap<>();
                adminData.put("role", "admin");

                // Save to 'Admins' collection so SignInActivity recognizes them
                db.collection("Admins").document(newAdminEmail)
                        .set(adminData)
                        .addOnSuccessListener(aVoid ->
                                Toast.makeText(this, newAdminEmail + " added as Admin!", Toast.LENGTH_LONG).show())
                        .addOnFailureListener(e ->
                                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}