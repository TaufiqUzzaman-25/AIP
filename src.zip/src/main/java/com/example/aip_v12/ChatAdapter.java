package com.example.aip_v12;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Environment;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.List;

import io.noties.markwon.Markwon;
import io.noties.markwon.ext.tables.TablePlugin;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    private List<String> messages;
    private Context context;

    public ChatAdapter(List<String> messages, Context context) {
        this.messages = messages;
        this.context = context;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        String message = messages.get(position);

        if (message.startsWith("You: ")) {
            holder.layoutAiContainer.setVisibility(View.GONE);
            String userText = message.substring(5);

            if (userText.contains("[IMG]") && userText.contains("[/IMG]")) {
                int start = userText.indexOf("[IMG]") + 5;
                int end = userText.indexOf("[/IMG]");
                String imageUriString = userText.substring(start, end);

                try {
                    holder.ivUserImage.setVisibility(View.VISIBLE);
                    holder.ivUserImage.setImageURI(Uri.parse(imageUriString));
                } catch (Exception e) {
                    holder.ivUserImage.setVisibility(View.GONE);
                }
                userText = userText.replace("[IMG]" + imageUriString + "[/IMG]", "").trim();
            } else {
                holder.ivUserImage.setVisibility(View.GONE);
            }

            if (userText.isEmpty()) {
                holder.tvUserMessage.setVisibility(View.GONE);
            } else {
                holder.tvUserMessage.setVisibility(View.VISIBLE);
                holder.tvUserMessage.setText(userText);
            }

        } else if (message.startsWith("A.I.P: ")) {
            holder.layoutAiContainer.setVisibility(View.VISIBLE);
            holder.tvUserMessage.setVisibility(View.GONE);
            if(holder.ivUserImage != null) holder.ivUserImage.setVisibility(View.GONE);

            String cleanAiMessage = message.substring(7);

            // --- THE NEW LOADING LOGIC ---
            if (cleanAiMessage.equals("[LOADING]")) {
                holder.layoutThinkingToggle.setVisibility(View.VISIBLE);
                holder.tvThinkingLabel.setText("Thinking...");
                holder.tvAiMessage.setVisibility(View.GONE);
                holder.tvThinkingContent.setVisibility(View.GONE);
                holder.layoutWarning.setVisibility(View.GONE);
                holder.btnExportPdf.setVisibility(View.GONE);

                // Infinite Pulse Animation
                ObjectAnimator pulse = (ObjectAnimator) holder.iconSparkle.getTag();
                if (pulse == null) {
                    pulse = ObjectAnimator.ofFloat(holder.iconSparkle, "alpha", 1f, 0.3f);
                    pulse.setDuration(600);
                    pulse.setRepeatCount(ValueAnimator.INFINITE);
                    pulse.setRepeatMode(ValueAnimator.REVERSE);
                    holder.iconSparkle.setTag(pulse);
                }
                pulse.start();

            } else {
                // --- FINISHED STATE LOGIC ---
                holder.tvAiMessage.setVisibility(View.VISIBLE);

                // Hide the thinking toggle completely for all finished messages
                holder.layoutThinkingToggle.setVisibility(View.GONE);
                holder.tvThinkingContent.setVisibility(View.GONE);

                // Stop the pulse animation
                ObjectAnimator pulse = (ObjectAnimator) holder.iconSparkle.getTag();
                if (pulse != null) {
                    pulse.cancel();
                }
                holder.iconSparkle.setAlpha(1f);

                String displayMessage = cleanAiMessage;

                // --- DRUG INTERACTION CHECKER ---
                if (cleanAiMessage.contains("WARNING:")) {
                    holder.layoutWarning.setVisibility(View.VISIBLE);
                    int warningEnd = cleanAiMessage.indexOf("\n\n");
                    if(warningEnd == -1) warningEnd = cleanAiMessage.length();

                    holder.tvWarningText.setText(cleanAiMessage.substring(0, warningEnd));
                    displayMessage = cleanAiMessage.substring(warningEnd).trim(); // Remove warning from main text
                } else {
                    holder.layoutWarning.setVisibility(View.GONE);
                }

                // Show PDF button for actual parsed data
                if (displayMessage.contains("| Medicine Name |") || displayMessage.length() > 100) {
                    holder.btnExportPdf.setVisibility(View.VISIBLE);
                    String finalDisplayMessage = displayMessage;
                    holder.btnExportPdf.setOnClickListener(v -> exportToPdfAndShare(finalDisplayMessage));
                } else {
                    holder.btnExportPdf.setVisibility(View.GONE);
                }

                Markwon markwon = Markwon.builder(context)
                        .usePlugin(TablePlugin.create(context))
                        .build();

                markwon.setMarkdown(holder.tvAiMessage, displayMessage);

                // THE FIX: Save it to a final variable before passing it into the lambda
                final String textForAlarms = displayMessage;

                holder.tvAiMessage.setOnLongClickListener(v -> {
                    autoDetectAndSetReminders(textForAlarms);
                    return true;
                });
            }
        }
    }

    // --- NATIVE PDF DOWNLOAD & SHARE METHOD ---
    private void exportToPdfAndShare(String textToExport) {
        PdfDocument pdfDocument = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create(); // A4 Size
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        TextPaint textPaint = new TextPaint();
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(14f);

        // StaticLayout handles automatic line wrapping for the PDF!
        StaticLayout staticLayout = new StaticLayout(textToExport, textPaint, pageInfo.getPageWidth() - 60, Layout.Alignment.ALIGN_NORMAL, 1.2f, 0.0f, false);

        canvas.translate(30, 30); // Margins
        staticLayout.draw(canvas);
        pdfDocument.finishPage(page);

        try {
            String fileName = "Prescription_Table_" + System.currentTimeMillis() + ".pdf";

            // 1. SAVE TO PUBLIC DOWNLOADS FOLDER (So the user can find it in their files)
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

            Uri downloadUri = context.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (downloadUri != null) {
                java.io.OutputStream out = context.getContentResolver().openOutputStream(downloadUri);
                pdfDocument.writeTo(out); // Write to the public Downloads folder
                out.close();
                Toast.makeText(context, "Table Downloaded to My Files/Downloads!", Toast.LENGTH_LONG).show();
            }

            // 2. SAVE TO INTERNAL FILE PROVIDER (So WhatsApp/Gmail can share it safely)
            File shareFile = new File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName);
            FileOutputStream fos = new FileOutputStream(shareFile);
            pdfDocument.writeTo(fos); // Write to internal cache for sharing
            fos.close();
            pdfDocument.close();

            // 3. TRIGGER SHARE MENU
            Uri shareUri = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".provider", shareFile);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/pdf");
            shareIntent.putExtra(Intent.EXTRA_STREAM, shareUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(Intent.createChooser(shareIntent, "Table Downloaded! Also share via..."));

        } catch (Exception e) {
            Toast.makeText(context, "Download Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // --- ALARM NOTIFICATION SYSTEM (100% UNTOUCHED) ---
    private void autoDetectAndSetReminders(String aiMessage) {
        boolean alarmsCreated = false;
        String[] lines = aiMessage.split("\\r?\\n");

        for (String line : lines) {
            if (line.contains("---")) continue;

            if (line.contains("|")) {
                String lowerLine = line.toLowerCase();
                if (lowerLine.contains("medicine name") || lowerLine.contains("dosage") || lowerLine.contains("timing")) continue;

                boolean foundSchedule = false;
                int morning = 0, noon = 0, night = 0;

                java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("(\\d)\\s*[\\+\\-&,]\\s*(\\d)\\s*[\\+\\-&,]\\s*(\\d)");
                java.util.regex.Matcher matcher = pattern.matcher(line);

                if (matcher.find()) {
                    morning = Integer.parseInt(matcher.group(1));
                    noon = Integer.parseInt(matcher.group(2));
                    night = Integer.parseInt(matcher.group(3));
                    foundSchedule = true;
                } else {
                    if (lowerLine.contains("morning") || lowerLine.contains("সকাল") || lowerLine.contains("breakfast")) {
                        morning = 1; foundSchedule = true;
                    }
                    if (lowerLine.contains("noon") || lowerLine.contains("afternoon") || lowerLine.contains("দুপুর") || lowerLine.contains("lunch")) {
                        noon = 1; foundSchedule = true;
                    }
                    if (lowerLine.contains("night") || lowerLine.contains("রাত") || lowerLine.contains("bedtime") || lowerLine.contains("dinner")) {
                        night = 1; foundSchedule = true;
                    }

                    if (!foundSchedule) {
                        if (lowerLine.contains("twice") || lowerLine.contains("2 times") || lowerLine.contains("২ বার")) {
                            morning = 1; night = 1; foundSchedule = true;
                        } else if (lowerLine.contains("thrice") || lowerLine.contains("3 times") || lowerLine.contains("৩ বার")) {
                            morning = 1; noon = 1; night = 1; foundSchedule = true;
                        } else if (lowerLine.contains("once") || lowerLine.contains("1 time") || lowerLine.contains("১ বার") || lowerLine.contains("daily")) {
                            morning = 1; foundSchedule = true;
                        }
                    }
                }

                if (foundSchedule) {
                    try {
                        String[] cols = line.split("\\|");
                        String medName = "Medicine";
                        if (cols.length > 1) {
                            medName = cols[1].replace("*", "").replace("`", "").trim();
                        }

                        if (morning > 0) ReminderManager.setReminder(context, "Take " + medName + " (Morning)", 10, 0);
                        if (noon > 0) ReminderManager.setReminder(context, "Take " + medName + " (Afternoon)", 14, 0);
                        if (night > 0) ReminderManager.setReminder(context, "Take " + medName + " (Night)", 21, 30);
                        alarmsCreated = true;
                    } catch (Exception ignored) { }
                }
            }
        }

        if (alarmsCreated) {
            Toast.makeText(context, "Smart Alarms Set!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Could not auto-read table. Setting manual alarm.", Toast.LENGTH_SHORT).show();
            showReminderPicker(aiMessage);
        }
    }

    private void showReminderPicker(String medicationInfo) {
        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(context, (view, selectedHour, selectedMinute) -> {
            ReminderManager.setReminder(context, medicationInfo, selectedHour, selectedMinute);
            Toast.makeText(context, "Manual Reminder Set!", Toast.LENGTH_SHORT).show();
        }, hour, minute, false);

        timePickerDialog.setTitle("Set Medication Time");
        timePickerDialog.show();
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public static class ChatViewHolder extends RecyclerView.ViewHolder {
        TextView tvUserMessage, tvAiMessage, tvWarningText;
        ImageView ivUserImage, iconSparkle, iconChevron;
        LinearLayout layoutAiContainer, layoutThinkingToggle, layoutWarning;
        TextView tvThinkingLabel, tvThinkingContent;
        Button btnExportPdf;

        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUserMessage = itemView.findViewById(R.id.tvUserMessage);
            tvAiMessage = itemView.findViewById(R.id.tvAiMessage);
            ivUserImage = itemView.findViewById(R.id.ivUserImage);

            layoutAiContainer = itemView.findViewById(R.id.layoutAiContainer);
            layoutThinkingToggle = itemView.findViewById(R.id.layoutThinkingToggle);
            tvThinkingLabel = itemView.findViewById(R.id.tvThinkingLabel);
            tvThinkingContent = itemView.findViewById(R.id.tvThinkingContent);
            iconChevron = itemView.findViewById(R.id.iconChevron);
            iconSparkle = itemView.findViewById(R.id.iconSparkle);

            // New Warning and PDF UI Binds
            layoutWarning = itemView.findViewById(R.id.layoutWarning);
            tvWarningText = itemView.findViewById(R.id.tvWarningText);
            btnExportPdf = itemView.findViewById(R.id.btnExportPdf);

            // Toggle logic for the dropdown chevron
            layoutThinkingToggle.setOnClickListener(v -> {
                if (tvThinkingContent.getVisibility() == View.VISIBLE) {
                    tvThinkingContent.setVisibility(View.GONE);
                    iconChevron.animate().rotation(0f).setDuration(200).start();
                } else {
                    tvThinkingContent.setVisibility(View.VISIBLE);
                    iconChevron.animate().rotation(180f).setDuration(200).start();
                }
            });
        }
    }
}