package com.example.aip_v12;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static CartManager instance;
    private List<Medicine> cartItems;

    private CartManager() {
        cartItems = new ArrayList<>();
    }

    public static synchronized CartManager getInstance() {
        if (instance == null) {
            instance = new CartManager();
        }
        return instance;
    }

    public void addToCart(Medicine medicine) {
        for (Medicine item : cartItems) {
            if (item.getName().equals(medicine.getName())) {
                item.setQuantity(item.getQuantity() + medicine.getQuantity());
                return;
            }
        }
        cartItems.add(medicine);
    }

    public List<Medicine> getCartItems() {
        return cartItems;
    }

    public double calculateTotal() {
        double total = 0;
        for (Medicine med : cartItems) {
            total += med.getPrice() * med.getQuantity();
        }
        return total;
    }

    // NEW: Function to remove items
    public void removeFromCart(String medicineName) {
        for (int i = 0; i < cartItems.size(); i++) {
            if (cartItems.get(i).getName().equals(medicineName)) {
                cartItems.remove(i);
                break;
            }
        }
    }

    public void clearCart() {
        cartItems.clear();
    }
}