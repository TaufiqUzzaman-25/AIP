package com.example.aip_v12;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// NEW: Firebase Imports for Memory Separation
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ChatFragment extends Fragment {

    private static final String API_KEY = "GEMINI API KEY";
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + API_KEY;

    private static final String PREFS_NAME = "AIP_Chat_Sessions";

    // UI Elements
    private DrawerLayout drawerLayout;
    private ListView listSidebarHistory;
    private RecyclerView recyclerView;
    private EditText etMessage;
    private ImageButton btnSend, btnCamera, btnGallery, btnOpenMenu;
    private Button btnNewChat;

    // Image Preview Elements
    private FrameLayout layoutImagePreview;
    private ImageView ivPreview;
    private ImageButton btnClearPreview;

    // Chat Logic
    private ChatAdapter adapter;
    private List<String> messages;
    private OkHttpClient client;
    private Bitmap selectedImage = null;
    private JSONArray chatHistory = new JSONArray();

    // Session Management
    private SharedPreferences prefs;
    private String currentSessionId = "";
    private List<String> sessionIds = new ArrayList<>();
    private List<String> sessionTitles = new ArrayList<>();
    private ArrayAdapter<String> sidebarAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chat, container, false);

        // Bind Views
        drawerLayout = view.findViewById(R.id.drawer_layout);
        listSidebarHistory = view.findViewById(R.id.list_sidebar_history);
        recyclerView = view.findViewById(R.id.recycler_chat);
        etMessage = view.findViewById(R.id.etMessage);
        btnSend = view.findViewById(R.id.btnSend);
        btnCamera = view.findViewById(R.id.btnCamera);
        btnGallery = view.findViewById(R.id.btnGallery);
        btnOpenMenu = view.findViewById(R.id.btnOpenMenu);
        btnNewChat = view.findViewById(R.id.btnNewChat);

        // Bind Preview Elements
        layoutImagePreview = view.findViewById(R.id.layoutImagePreview);
        ivPreview = view.findViewById(R.id.ivPreview);
        btnClearPreview = view.findViewById(R.id.btnClearPreview);

        // --- NEW MEMORY SEPARATION LOGIC ---
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String uniquePrefName = PREFS_NAME; // Fallback

        if (user != null) {
            // Make the memory file completely unique to this specific email's UID!
            uniquePrefName = PREFS_NAME + "_" + user.getUid();
        }

        // Initialize SharedPreferences using their UNIQUE memory file
        prefs = requireContext().getSharedPreferences(uniquePrefName, Context.MODE_PRIVATE);
        // --- END MEMORY SEPARATION LOGIC ---

        messages = new ArrayList<>();
        adapter = new ChatAdapter(messages, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        // Network timeout handles the long AI generation times
        client = new OkHttpClient.Builder()
                .connectTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS).build();

        // Setup Sidebar Interactions
        btnOpenMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        btnNewChat.setOnClickListener(v -> createNewSession());

        sidebarAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, sessionTitles);
        listSidebarHistory.setAdapter(sidebarAdapter);
        listSidebarHistory.setOnItemClickListener((parent, view1, position, id) -> {
            loadSession(sessionIds.get(position));
            drawerLayout.closeDrawer(GravityCompat.START);
        });

        // Initialize Chat Data
        loadAllSessions();
        if (sessionIds.isEmpty()) {
            createNewSession();
        } else {
            loadSession(sessionIds.get(0));
        }

        // --- IMAGE ATTACHMENT LOGIC ---
        ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        selectedImage = (Bitmap) result.getData().getExtras().get("data");
                        showImagePreview(selectedImage);
                    }
                });

        ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        try {
                            selectedImage = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), result.getData().getData());
                            showImagePreview(selectedImage);
                        } catch (IOException e) { e.printStackTrace(); }
                    }
                });

        btnCamera.setOnClickListener(v -> {
            try { cameraLauncher.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE)); }
            catch (ActivityNotFoundException e) { Toast.makeText(getContext(), "No Camera App found!", Toast.LENGTH_LONG).show(); }
        });

        btnGallery.setOnClickListener(v -> {
            try { galleryLauncher.launch(new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)); }
            catch (Exception e) { Toast.makeText(getContext(), "Gallery Error", Toast.LENGTH_LONG).show(); }
        });

        // Clear Preview Button
        btnClearPreview.setOnClickListener(v -> {
            selectedImage = null;
            layoutImagePreview.setVisibility(View.GONE);
            etMessage.setHint("Type or attach...");
        });

        btnSend.setOnClickListener(v -> {
            String text = etMessage.getText().toString().trim();
            if (!text.isEmpty() || selectedImage != null) {
                String displayMsg = text;

                // Embed the image path securely if an image is selected
                if (selectedImage != null) {
                    String imagePath = saveImageToInternalStorage(selectedImage);
                    displayMsg = "[IMG]" + imagePath + "[/IMG] " + text;
                }

                // 1. Instantly add the User's message FIRST
                messages.add("You: " + displayMsg.trim());
                adapter.notifyItemInserted(messages.size() - 1);

                // Reset UI
                etMessage.setText("");
                etMessage.setHint("Type a message...");
                layoutImagePreview.setVisibility(View.GONE);

                // 2. Instantly add the AI "Thinking..." message SECOND
                messages.add("A.I.P: [LOADING]");
                final int loadingIndex = messages.size() - 1;
                adapter.notifyItemInserted(loadingIndex);

                // Scroll to the very bottom
                recyclerView.scrollToPosition(loadingIndex);

                // Save the history correctly
                saveChatHistory();

                // Call AI and pass the index of the loading message
                callGeminiAPI(text, selectedImage, loadingIndex);
                selectedImage = null;
            }
        });

        return view;
    }

    // --- HELPER: SHOW PREVIEW ---
    private void showImagePreview(Bitmap bitmap) {
        ivPreview.setImageBitmap(bitmap);
        layoutImagePreview.setVisibility(View.VISIBLE);
        etMessage.setHint("Add a caption...");
    }

    // --- HELPER: SAVE IMAGE LOCALLY FOR ADAPTER ---
    private String saveImageToInternalStorage(Bitmap bitmap) {
        try {
            java.io.File file = new java.io.File(requireContext().getFilesDir(), "chat_img_" + System.currentTimeMillis() + ".png");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            return android.net.Uri.fromFile(file).toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    // --- SESSION MANAGEMENT LOGIC ---
    private void loadAllSessions() {
        sessionIds.clear();
        sessionTitles.clear();
        try {
            JSONArray arr = new JSONArray(prefs.getString("all_sessions", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                String id = arr.getString(i);
                sessionIds.add(id);
                sessionTitles.add(prefs.getString(id + "_title", "Chat " + (arr.length() - i)));
            }
        } catch (JSONException e) { e.printStackTrace(); }
        sidebarAdapter.notifyDataSetChanged();
    }

    private void createNewSession() {
        currentSessionId = "chat_" + System.currentTimeMillis();
        sessionIds.add(0, currentSessionId);
        sessionTitles.add(0, "New Conversation");

        JSONArray arr = new JSONArray();
        for (String id : sessionIds) arr.put(id);
        prefs.edit().putString("all_sessions", arr.toString()).apply();
        sidebarAdapter.notifyDataSetChanged();

        messages.clear();
        chatHistory = new JSONArray();
        adapter.notifyDataSetChanged();

        // Add welcome message synchronously
        messages.add("A.I.P: Hello! It's good to hear from you. How can I assist you today?");
        adapter.notifyItemInserted(messages.size() - 1);

        drawerLayout.closeDrawer(GravityCompat.START);
    }

    private void loadSession(String sessionId) {
        currentSessionId = sessionId;
        messages.clear();
        chatHistory = new JSONArray();
        try {
            JSONArray msgArray = new JSONArray(AESUtils.decrypt(prefs.getString(sessionId + "_msgs", AESUtils.encrypt("[]"))));
            for (int i = 0; i < msgArray.length(); i++) {
                String msg = msgArray.getString(i);
                messages.add(msg);

                // Reconstruct Gemini Memory
                JSONObject modelMessage = new JSONObject();
                if (msg.startsWith("You: ")) {
                    modelMessage.put("role", "user");
                    String cleanUserText = msg.substring(5).replaceAll("\\[IMG\\].*?\\[/IMG\\]", "").trim();
                    modelMessage.put("parts", new JSONArray().put(new JSONObject().put("text", cleanUserText)));
                    chatHistory.put(modelMessage);
                } else if (msg.startsWith("A.I.P: ")) {
                    modelMessage.put("role", "model");
                    modelMessage.put("parts", new JSONArray().put(new JSONObject().put("text", msg.substring(7))));
                    chatHistory.put(modelMessage);
                }
            }
        } catch (JSONException e) { e.printStackTrace(); }

        adapter.notifyDataSetChanged();
        if (!messages.isEmpty()) recyclerView.scrollToPosition(messages.size() - 1);
    }

    private void saveChatHistory() {
        JSONArray msgArray = new JSONArray();
        for (String msg : messages) msgArray.put(msg);

        prefs.edit().putString(currentSessionId + "_msgs", AESUtils.encrypt(msgArray.toString())).apply();

        if (messages.size() == 2) {
            String firstMsg = messages.get(1);
            String title = firstMsg.substring(5, Math.min(firstMsg.length(), 30)).replaceAll("\\[IMG\\].*?\\[/IMG\\]", "").trim();
            if(title.isEmpty()) title = "Image Upload";
            prefs.edit().putString(currentSessionId + "_title", title).apply();

            int index = sessionIds.indexOf(currentSessionId);
            if (index != -1) {
                sessionTitles.set(index, title);
                sidebarAdapter.notifyDataSetChanged();
            }
        }
    }

    // --- GEMINI API & MESSAGING LOGIC ---
    private String getBase64FromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, baos);
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
    }

    private void callGeminiAPI(String userText, Bitmap image, int loadingIndex) {
        try {
            JSONArray currentParts = new JSONArray();
            String finalPrompt = "";

            if (image != null) {
                finalPrompt = "You are a medical prescription analyzer. When analyzing prescription images:\n" +
                        "1. List all medications, dosages, and durations.\n" +
                        "2. Translate Bengali instructions to English in parentheses.\n" +
                        "3. Extract the doctor's name and date.\n" +
                        "4. Extract vital signs (BP/Weight).\n" +
                        "5. Provide a short summary of the prescription.\n" +
                        "6. Identify the reason the medicine is prescribed.\n" +
                        "7. STRICTLY create a Markdown table for the medicine schedule using this EXACT format. You MUST use the '1+0+1' number format in the Dosage column. DO NOT use text words like 'Morning' or 'Night' in the Dosage column:\n" +
                        "| Medicine Name | Dosage (e.g., 1+0+1) | Timing | Duration |\n" +
                        "|---|---|---|---|\n" +
                        "| Example Med | 1+0+1 | After Food | 7 Days |\n" +
                        "8. For the patient's safety, cross-reference these newly prescribed medications against this list of the patient's currently active medicines: [Aspirin, Lisinopril, Ibuprofen]. If there is a moderate or severe drug interaction risk, you MUST start your entire response exactly with 'WARNING: [Explain the interaction]'. Then hit enter twice and provide the table.\n\n" +
                        "Format your response cleanly. User query: " + userText;

            } else {
                finalPrompt = "You are a helpful medical assistant. " + userText;
            }

            currentParts.put(new JSONObject().put("text", finalPrompt));

            if (image != null) {
                JSONObject inlineData = new JSONObject();
                inlineData.put("mimeType", "image/jpeg");
                inlineData.put("data", getBase64FromBitmap(image));
                currentParts.put(new JSONObject().put("inlineData", inlineData));
            }

            JSONObject userMessage = new JSONObject().put("role", "user").put("parts", currentParts);
            chatHistory.put(userMessage);

            RequestBody body = RequestBody.create(new JSONObject().put("contents", chatHistory).toString(), MediaType.get("application/json; charset=utf-8"));
            Request request = new Request.Builder().url(API_URL).post(body).header("Content-Type", "application/json").build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    chatHistory.remove(chatHistory.length() - 1);
                    new Handler(Looper.getMainLooper()).post(() -> {
                        messages.set(loadingIndex, "A.I.P: Network Failure - " + e.getMessage());
                        adapter.notifyItemChanged(loadingIndex);
                        saveChatHistory();
                    });
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    String responseBody = response.body() != null ? response.body().string() : "No message";
                    if (response.isSuccessful()) {
                        try {
                            String aiResponse = new JSONObject(responseBody)
                                    .getJSONArray("candidates").getJSONObject(0)
                                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");

                            JSONObject modelMessage = new JSONObject().put("role", "model")
                                    .put("parts", new JSONArray().put(new JSONObject().put("text", aiResponse)));
                            chatHistory.put(modelMessage);

                            new Handler(Looper.getMainLooper()).post(() -> {
                                messages.set(loadingIndex, "A.I.P: " + aiResponse);
                                adapter.notifyItemChanged(loadingIndex);
                                saveChatHistory();
                            });
                        } catch (JSONException e) {
                            new Handler(Looper.getMainLooper()).post(() -> {
                                messages.set(loadingIndex, "A.I.P: Error parsing response.");
                                adapter.notifyItemChanged(loadingIndex);
                                saveChatHistory();
                            });
                        }
                    } else {
                        chatHistory.remove(chatHistory.length() - 1);
                        new Handler(Looper.getMainLooper()).post(() -> {
                            // UPDATED: Catching the 503 error so the UI stays clean!
                            if (response.code() == 503) {
                                messages.set(loadingIndex, "A.I.P: I am currently experiencing high traffic. Please wait a moment and try again.");
                            } else {
                                messages.set(loadingIndex, "A.I.P: API Error " + response.code() + ": " + responseBody);
                            }
                            adapter.notifyItemChanged(loadingIndex);
                            saveChatHistory();
                        });
                    }
                }
            });
        } catch (JSONException e) { e.printStackTrace(); }
    }
}