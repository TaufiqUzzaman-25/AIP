package com.example.aip_v12;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Map;

public class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.ViewHolder> {
    private List<Map<String, Object>> orders;

    public OrdersAdapter(List<Map<String, Object>> orders) {
        this.orders = orders;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Map<String, Object> order = orders.get(position);

        holder.tvOrderName.setText(String.valueOf(order.get("customerName")));

        // Combine Phone and Email for the Admin to see
        String contactInfo = "📞 " + order.get("phone") + " | 📧 " + order.get("email");
        holder.tvOrderContact.setText(contactInfo);

        holder.tvOrderAddress.setText("📍 " + (order.get("address") != null ? order.get("address") : "No Address"));
        holder.tvOrderTotal.setText("Total: ৳ " + order.get("totalPrice"));

        // Display the multiplied quantity list we built in CartFragment
        List<String> items = (List<String>) order.get("medicines");
        StringBuilder sb = new StringBuilder("Items Ordered:");
        if (items != null) {
            for (String item : items) {
                sb.append("\n• ").append(item);
            }
        }
        holder.tvOrderItems.setText(sb.toString());
    }

    @Override
    public int getItemCount() { return orders.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderName, tvOrderContact, tvOrderAddress, tvOrderItems, tvOrderTotal;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderName = itemView.findViewById(R.id.tvOrderName);
            tvOrderContact = itemView.findViewById(R.id.tvOrderContact); // The new ID
            tvOrderAddress = itemView.findViewById(R.id.tvOrderAddress);
            tvOrderItems = itemView.findViewById(R.id.tvOrderItems);
            tvOrderTotal = itemView.findViewById(R.id.tvOrderTotal);
        }
    }
}