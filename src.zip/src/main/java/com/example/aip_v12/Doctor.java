package com.example.aip_v12;

public class Doctor {
    private String id; // NEW: Needed for deletion
    private String name;
    private String specialty;
    private String availableTime;
    private double rating;

    // Primary constructor for database
    public Doctor(String id, String name, String specialty, String availableTime, double rating) {
        this.id = id;
        this.name = name;
        this.specialty = specialty;
        this.availableTime = availableTime;
        this.rating = rating;
    }

    // Safe fallback constructor so other files don't break
    public Doctor(String name, String specialty, String availableTime, double rating) {
        this.id = "";
        this.name = name;
        this.specialty = specialty;
        this.availableTime = availableTime;
        this.rating = rating;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getSpecialty() { return specialty; }
    public String getAvailableTime() { return availableTime; }
    public double getRating() { return rating; }

    @Override
    public String toString() {
        return name + " (" + specialty + ") - ⭐ " + rating + "\nTime: " + availableTime;
    }
}