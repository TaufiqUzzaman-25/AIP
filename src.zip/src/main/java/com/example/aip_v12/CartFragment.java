package com.example.aip_v12;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartFragment extends Fragment {

    private LinearLayout receiptContainer;
    private TextView tvTotalPrice;
    private Button btnPlaceOrder;
    private EditText etName, etEmail, etPhone, etAddress;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart, container, false);

        receiptContainer = view.findViewById(R.id.receiptContainer);
        tvTotalPrice = view.findViewById(R.id.tvTotalPrice);
        btnPlaceOrder = view.findViewById(R.id.btnPlaceOrder);

        etName = view.findViewById(R.id.etName);
        etEmail = view.findViewById(R.id.etEmail);
        etPhone = view.findViewById(R.id.etPhone);
        etAddress = view.findViewById(R.id.etAddress);

        // Load the UI dynamically
        loadCartUI();

        btnPlaceOrder.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String address = etAddress.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty()) {
                Toast.makeText(getContext(), "Please fill out all details.", Toast.LENGTH_LONG).show();
                return;
            }

            List<Medicine> cartItems = CartManager.getInstance().getCartItems();
            if (cartItems.isEmpty()) {
                Toast.makeText(getContext(), "Cart is empty!", Toast.LENGTH_SHORT).show();
                return;
            }

            btnPlaceOrder.setEnabled(false);
            double total = CartManager.getInstance().calculateTotal();

            Map<String, Object> order = new HashMap<>();
            order.put("customerName", name);
            order.put("email", email);
            order.put("phone", phone);
            order.put("address", address);
            order.put("totalPrice", total);
            order.put("timestamp", com.google.firebase.Timestamp.now());

            List<String> items = new ArrayList<>();
            for (Medicine med : cartItems) {
                double itemTotal = med.getPrice() * med.getQuantity();
                items.add(med.getName() + " (x" + med.getQuantity() + ") - ৳" + itemTotal);
            }
            order.put("medicines", items);

            FirebaseFirestore.getInstance().collection("Orders").add(order)
                    .addOnSuccessListener(doc -> {
                        Toast.makeText(getContext(), "Order Placed Successfully!", Toast.LENGTH_LONG).show();
                        CartManager.getInstance().clearCart();
                        if (isAdded()) getParentFragmentManager().popBackStack();
                    })
                    .addOnFailureListener(e -> {
                        btnPlaceOrder.setEnabled(true);
                        Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });

        return view;
    }

    // NEW: Helper function to draw and refresh the cart items
    private void loadCartUI() {
        receiptContainer.removeAllViews();
        List<Medicine> cartItems = CartManager.getInstance().getCartItems();

        if (cartItems.isEmpty()) {
            TextView emptyText = new TextView(getContext());
            emptyText.setText("Your cart is empty.");
            receiptContainer.addView(emptyText);
            tvTotalPrice.setText("৳ 0.0");
            return;
        }

        for (Medicine med : cartItems) {
            LinearLayout itemLayout = new LinearLayout(getContext());
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setPadding(0, 8, 0, 8);
            itemLayout.setGravity(Gravity.CENTER_VERTICAL);

            TextView itemText = new TextView(getContext());
            double subTotal = med.getPrice() * med.getQuantity();
            itemText.setText("• " + med.getName() + " (Qty: " + med.getQuantity() + ") - ৳ " + subTotal);
            itemText.setTextSize(15f);
            itemText.setTextColor(getResources().getColor(android.R.color.black));
            itemText.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            // Create the Remove button
            Button btnRemove = new Button(getContext());
            btnRemove.setText("X");
            btnRemove.setTextColor(Color.WHITE);
            btnRemove.setBackgroundTintList(ColorStateList.valueOf(Color.RED));

            // Make button compact
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            btnParams.setMargins(16, 0, 0, 0);
            btnRemove.setLayoutParams(btnParams);

            // OnClick to remove and refresh
            btnRemove.setOnClickListener(v -> {
                CartManager.getInstance().removeFromCart(med.getName());
                loadCartUI();
            });

            itemLayout.addView(itemText);
            itemLayout.addView(btnRemove);
            receiptContainer.addView(itemLayout);
        }

        double total = CartManager.getInstance().calculateTotal();
        tvTotalPrice.setText("৳ " + total);
    }
}