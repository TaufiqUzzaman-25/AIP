package com.example.aip_v12;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class AdminViewLogsActivity extends AppCompatActivity {

    private ListView listAppointments;
    private FirebaseFirestore db;
    private List<String> appointmentList = new ArrayList<>();
    private List<String> appointmentIds = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Make sure this matches your XML file name perfectly!
        setContentView(R.layout.activity_admin_view_logs);

        db = FirebaseFirestore.getInstance();
        listAppointments = findViewById(R.id.listAppointments);

        // Upgraded Adapter to FORCE the text to be Black and visible
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, appointmentList) {
            @NonNull
            @Override
            public android.view.View getView(int position, @Nullable android.view.View convertView, @NonNull android.view.ViewGroup parent) {
                android.view.View view = super.getView(position, convertView, parent);
                android.widget.TextView text = view.findViewById(android.R.id.text1);
                text.setTextColor(android.graphics.Color.BLACK); // Forces text to show up!
                text.setTextSize(16f);
                text.setPadding(0, 20, 0, 20); // Adds a little spacing
                return view;
            }
        };
        listAppointments.setAdapter(adapter);

        // Long Press to Delete / Complete the appointment
        listAppointments.setOnItemLongClickListener((parent, view, position, id) -> {
            String docId = appointmentIds.get(position);
            db.collection("Appointments").document(docId).delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Appointment Completed & Removed", Toast.LENGTH_SHORT).show();
                        fetchAppointments(); // Refresh the list
                    });
            return true;
        });

        fetchAppointments();
    }

    private void fetchAppointments() {
        db.collection("Appointments").get().addOnSuccessListener(queryDocumentSnapshots -> {
            appointmentList.clear();
            appointmentIds.clear();

            for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                String doctorName = doc.getString("doctorName");
                String date = doc.getString("date");
                String time = doc.getString("time");

                // NEW: Fetch the Patient Name and Phone
                String patientName = doc.getString("patientName");
                String patientPhone = doc.getString("patientPhone");

                // Handle old appointments that didn't have names
                if (patientName == null) patientName = "Unknown Patient";
                if (patientPhone == null) patientPhone = "No Phone";

                // Build the new display text
                String displayText = "Patient: " + patientName + " (" + patientPhone + ")\n" +
                        "Dr. " + doctorName + "\nDate: " + date + " | Time: " + time;

                appointmentList.add(displayText);
                appointmentIds.add(doc.getId()); // Store ID so we can delete it later
            }
            adapter.notifyDataSetChanged();
        }).addOnFailureListener(e ->
                Toast.makeText(this, "Error fetching appointments", Toast.LENGTH_SHORT).show()
        );
    }
}