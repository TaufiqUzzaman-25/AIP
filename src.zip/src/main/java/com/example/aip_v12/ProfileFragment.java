package com.example.aip_v12;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

// NEW: Google Sign-In Imports
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ProfileFragment extends Fragment {

    private static final String EXERCISE_API_KEY = "API";
    private static final String EXERCISE_API_HOST = "exercisedb.p.rapidapi.com";

    private TextView tvProfileEmail, tvBmiResult;
    private EditText etName, etAge, etHeight, etWeight;
    private ImageView ivProfilePic;
    private Button btnSignOut, btnSaveProfile, btnActionPlan;
    private LineChart weightChart;

    private SharedPreferences prefs;
    private static final String PREF_NAME = "UserProfilePrefs";
    private float currentBmi = 0f;

    // NEW: Google Sign-In Client variable
    private GoogleSignInClient mGoogleSignInClient;

    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    try {
                        Uri imageUri = result.getData().getData();
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(requireActivity().getContentResolver(), imageUri);
                        ivProfilePic.setImageBitmap(bitmap);
                        saveImageToPrefs(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        tvProfileEmail = view.findViewById(R.id.tvProfileEmail);
        tvBmiResult = view.findViewById(R.id.tvBmiResult);
        etName = view.findViewById(R.id.etProfileName);
        etAge = view.findViewById(R.id.etProfileAge);
        etHeight = view.findViewById(R.id.etProfileHeight);
        etWeight = view.findViewById(R.id.etProfileWeight);
        ivProfilePic = view.findViewById(R.id.ivProfilePic);
        btnSignOut = view.findViewById(R.id.btnSignOut);
        btnSaveProfile = view.findViewById(R.id.btnSaveProfile);
        btnActionPlan = view.findViewById(R.id.btnActionPlan);
        weightChart = view.findViewById(R.id.weightChart);

        // --- NEW MEMORY SEPARATION LOGIC ---

        // 1. Get the Current User FIRST
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String uniquePrefName = PREF_NAME; // Fallback name

        if (user != null) {
            tvProfileEmail.setText(user.getEmail());
            // Make the memory file completely unique to this specific email's UID!
            uniquePrefName = PREF_NAME + "_" + user.getUid();
        }

        // 2. Initialize SharedPreferences using their UNIQUE memory file
        prefs = requireContext().getSharedPreferences(uniquePrefName, Context.MODE_PRIVATE);

        // 3. Initialize Google Sign-In Client
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(requireActivity(), gso);

        // --- END MEMORY SEPARATION LOGIC ---

        setupChart();
        loadUserProfile();

        ivProfilePic.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            galleryLauncher.launch(intent);
        });

        btnSaveProfile.setOnClickListener(v -> calculateAndSaveProfile());

        btnActionPlan.setOnClickListener(v -> fetchExercisePlan());

        // UPDATED: Completely logs user out of Firebase and Google
        btnSignOut.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            mGoogleSignInClient.signOut().addOnCompleteListener(requireActivity(), task -> {
                Intent intent = new Intent(getActivity(), SignInActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                requireActivity().finish();
            });
        });

        return view;
    }

    private void calculateAndSaveProfile() {
        String name = etName.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();
        String heightStr = etHeight.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();

        if (heightStr.isEmpty() || weightStr.isEmpty()) {
            Toast.makeText(getContext(), "Please enter Height and Weight", Toast.LENGTH_SHORT).show();
            return;
        }

        float heightCm = Float.parseFloat(heightStr);
        float weightKg = Float.parseFloat(weightStr);
        float heightM = heightCm / 100f;
        currentBmi = weightKg / (heightM * heightM);

        tvBmiResult.setText(String.format("Your BMI: %.1f", currentBmi));
        updateChartWithNewBMI(currentBmi);

        btnActionPlan.setVisibility(View.VISIBLE);

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("name", name);
        editor.putString("age", ageStr);
        editor.putString("height", heightStr);
        editor.putString("weight", weightStr);
        editor.putFloat("last_bmi", currentBmi);
        editor.apply();
    }

    private void loadUserProfile() {
        etName.setText(prefs.getString("name", ""));
        etAge.setText(prefs.getString("age", ""));
        etHeight.setText(prefs.getString("height", ""));
        etWeight.setText(prefs.getString("weight", ""));

        currentBmi = prefs.getFloat("last_bmi", 0f);
        if (currentBmi > 0) {
            tvBmiResult.setText(String.format("Your BMI: %.1f", currentBmi));
            updateChartWithNewBMI(currentBmi);
            btnActionPlan.setVisibility(View.VISIBLE);
        } else {
            loadDummyData();
        }

        String encodedImage = prefs.getString("profile_image", "");
        if (!encodedImage.isEmpty()) {
            byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            ivProfilePic.setImageBitmap(decodedByte);
        }
    }

    private void fetchExercisePlan() {
        if (currentBmi == 0) return;

        btnActionPlan.setText("Fetching Plan...");
        btnActionPlan.setEnabled(false);

        String targetBodyPart = "cardio";
        String planTitle = "Fat-Burning Cardio Plan";

        if (currentBmi < 18.5f) {
            targetBodyPart = "chest";
            planTitle = "Muscle Building Strength Plan";
        } else if (currentBmi >= 18.5f && currentBmi < 25f) {
            targetBodyPart = "back";
            planTitle = "Maintenance & Posture Plan";
        }

        String url = "https://exercisedb.p.rapidapi.com/exercises/bodyPart/" + targetBodyPart + "?limit=5";

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("X-RapidAPI-Key", EXERCISE_API_KEY)
                .addHeader("X-RapidAPI-Host", EXERCISE_API_HOST)
                .build();

        String finalPlanTitle = planTitle;
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), "Failed to fetch plan. Check internet.", Toast.LENGTH_SHORT).show();
                    resetActionPlanButton();
                });
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    try {
                        String responseData = response.body().string();
                        JSONArray jsonArray = new JSONArray(responseData);
                        ArrayList<String> exerciseList = new ArrayList<>();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject exercise = jsonArray.getJSONObject(i);
                            String name = exercise.getString("name");
                            String equipment = exercise.getString("equipment");

                            name = name.substring(0, 1).toUpperCase() + name.substring(1);
                            exerciseList.add("• " + name + "\n  Equipment: " + equipment);
                        }

                        requireActivity().runOnUiThread(() -> {
                            showExerciseDialog(finalPlanTitle, exerciseList);
                            resetActionPlanButton();
                        });

                    } catch (JSONException e) {
                        requireActivity().runOnUiThread(() -> resetActionPlanButton());
                    }
                } else {
                    requireActivity().runOnUiThread(() -> resetActionPlanButton());
                }
            }
        });
    }

    private void showExerciseDialog(String title, ArrayList<String> exercises) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, exercises);
        new AlertDialog.Builder(requireContext())
                .setTitle(title)
                .setAdapter(adapter, null)
                .setPositiveButton("Got It!", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void resetActionPlanButton() {
        btnActionPlan.setText("🏋️ Get My Fitness Plan");
        btnActionPlan.setEnabled(true);
    }

    private void saveImageToPrefs(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] b = baos.toByteArray();
        String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
        prefs.edit().putString("profile_image", encodedImage).apply();
    }

    private void setupChart() {
        weightChart.getDescription().setEnabled(false);
        weightChart.getAxisRight().setEnabled(false);
        weightChart.setDrawGridBackground(false);

        XAxis xAxis = weightChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);

        YAxis leftAxis = weightChart.getAxisLeft();
        leftAxis.removeAllLimitLines();
        leftAxis.setAxisMinimum(10f);
        leftAxis.setAxisMaximum(40f);

        LimitLine underweightLine = new LimitLine(18.5f, "Underweight");
        underweightLine.setLineWidth(2f);
        underweightLine.setLineColor(Color.parseColor("#FFC107"));
        underweightLine.setTextColor(Color.parseColor("#FFC107"));

        LimitLine overweightLine = new LimitLine(25f, "Overweight");
        overweightLine.setLineWidth(2f);
        overweightLine.setLineColor(Color.parseColor("#FF9800"));
        overweightLine.setTextColor(Color.parseColor("#FF9800"));

        LimitLine obeseLine = new LimitLine(30f, "Obese");
        obeseLine.setLineWidth(2f);
        obeseLine.setLineColor(Color.parseColor("#FF3B30"));
        obeseLine.setTextColor(Color.parseColor("#FF3B30"));

        leftAxis.addLimitLine(underweightLine);
        leftAxis.addLimitLine(overweightLine);
        leftAxis.addLimitLine(obeseLine);
        leftAxis.setDrawLimitLinesBehindData(true);
    }

    private void updateChartWithNewBMI(float calculatedBmi) {
        ArrayList<Entry> entries = new ArrayList<>();
        entries.add(new Entry(1f, calculatedBmi + 1.2f));
        entries.add(new Entry(2f, calculatedBmi + 0.8f));
        entries.add(new Entry(3f, calculatedBmi + 0.3f));
        entries.add(new Entry(4f, calculatedBmi));

        LineDataSet dataSet = new LineDataSet(entries, "Your BMI");
        int lineColor = Color.parseColor("#00BF6D");
        if (calculatedBmi < 18.5f) lineColor = Color.parseColor("#FFC107");
        else if (calculatedBmi >= 30f) lineColor = Color.parseColor("#FF3B30");
        else if (calculatedBmi >= 25f) lineColor = Color.parseColor("#FF9800");

        dataSet.setColor(lineColor);
        dataSet.setCircleColor(lineColor);
        dataSet.setLineWidth(4f);
        dataSet.setCircleRadius(6f);
        dataSet.setDrawValues(true);
        dataSet.setValueTextSize(10f);

        LineData lineData = new LineData(dataSet);
        weightChart.setData(lineData);
        weightChart.invalidate();
    }

    private void loadDummyData() {
        ArrayList<Entry> entries = new ArrayList<>();
        entries.add(new Entry(1f, 22.0f));
        entries.add(new Entry(2f, 22.5f));
        entries.add(new Entry(3f, 23.0f));

        LineDataSet dataSet = new LineDataSet(entries, "Your BMI");
        dataSet.setColor(Color.parseColor("#00BF6D"));
        dataSet.setCircleColor(Color.parseColor("#00BF6D"));
        dataSet.setLineWidth(4f);
        dataSet.setCircleRadius(6f);

        LineData lineData = new LineData(dataSet);
        weightChart.setData(lineData);
        weightChart.invalidate();
    }
}