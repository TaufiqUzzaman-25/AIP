package com.example.aip_v12;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminAddDoctorActivity extends AppCompatActivity {

    private EditText etDocName, etDocSpecialty, etDocTime, etDocRating;
    private Button btnSaveDoctor;
    private ListView listDoctors;
    private FirebaseFirestore db;

    private List<Doctor> doctorList = new ArrayList<>();
    private ArrayAdapter<Doctor> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_doctor);

        db = FirebaseFirestore.getInstance();

        etDocName = findViewById(R.id.etDocName);
        etDocSpecialty = findViewById(R.id.etDocSpecialty);
        etDocTime = findViewById(R.id.etDocTime);
        etDocRating = findViewById(R.id.etDocRating);
        btnSaveDoctor = findViewById(R.id.btnSaveDoctor);
        listDoctors = findViewById(R.id.listDoctors);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, doctorList);
        listDoctors.setAdapter(adapter);

        btnSaveDoctor.setOnClickListener(v -> saveDoctorToFirebase());

        // NEW: Long Press to Delete
        listDoctors.setOnItemLongClickListener((parent, view, position, id) -> {
            Doctor doc = doctorList.get(position);
            db.collection("Doctors").document(doc.getId()).delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, doc.getName() + " Deleted", Toast.LENGTH_SHORT).show();
                        fetchDoctors(); // Refresh the list
                    });
            return true;
        });

        fetchDoctors();
    }

    private void fetchDoctors() {
        db.collection("Doctors").get().addOnSuccessListener(queryDocumentSnapshots -> {
            doctorList.clear();
            for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                doctorList.add(new Doctor(
                        doc.getId(),
                        doc.getString("name"),
                        doc.getString("specialty"),
                        doc.getString("availableTime"),
                        doc.getDouble("rating")
                ));
            }
            adapter.notifyDataSetChanged();
        });
    }

    private void saveDoctorToFirebase() {
        String name = etDocName.getText().toString().trim();
        String specialty = etDocSpecialty.getText().toString().trim();
        String time = etDocTime.getText().toString().trim();
        String ratingStr = etDocRating.getText().toString().trim();

        if (name.isEmpty() || specialty.isEmpty() || time.isEmpty() || ratingStr.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double rating = Double.parseDouble(ratingStr);

        Map<String, Object> doctor = new HashMap<>();
        doctor.put("name", name);
        doctor.put("specialty", specialty);
        doctor.put("availableTime", time);
        doctor.put("rating", rating);

        db.collection("Doctors").add(doctor)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Doctor Added Successfully!", Toast.LENGTH_SHORT).show();
                    etDocName.setText("");
                    etDocSpecialty.setText("");
                    etDocTime.setText("");
                    etDocRating.setText("");
                    fetchDoctors(); // Refresh the list instantly
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }
}