package com.example.aip_v12;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AdminViewOrdersActivity extends AppCompatActivity {
    private RecyclerView recyclerOrders;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_orders);

        db = FirebaseFirestore.getInstance();
        recyclerOrders = findViewById(R.id.recyclerOrders);
        recyclerOrders.setLayoutManager(new LinearLayoutManager(this));

        loadOrders();
    }

    private void loadOrders() {
        // Fetch orders and sort by newest first
        db.collection("Orders").orderBy("timestamp", Query.Direction.DESCENDING)
                .get().addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        List<Map<String, Object>> orderDataList = new ArrayList<>();
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            // Add the raw map data for the professional adapter
                            orderDataList.add(doc.getData());
                        }
                        // Set the new professional OrdersAdapter
                        recyclerOrders.setAdapter(new OrdersAdapter(orderDataList));
                    } else {
                        Toast.makeText(this, "Failed to load orders.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}