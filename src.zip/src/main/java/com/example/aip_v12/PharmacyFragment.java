package com.example.aip_v12;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class PharmacyFragment extends Fragment {

    private RecyclerView recyclerPharmacy;
    private Button btnViewCart;
    private EditText etSearchPharmacy;
    private PharmacyAdapter adapter;
    private List<Medicine> inventory = new ArrayList<>();
    private List<Medicine> filteredList = new ArrayList<>();
    private FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pharmacy, container, false);

        db = FirebaseFirestore.getInstance();
        recyclerPharmacy = view.findViewById(R.id.recycler_pharmacy);
        btnViewCart = view.findViewById(R.id.btnViewCart);
        etSearchPharmacy = view.findViewById(R.id.etSearchPharmacy);

        recyclerPharmacy.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new PharmacyAdapter(filteredList);
        recyclerPharmacy.setAdapter(adapter);

        loadMedicinesFromFirebase();

        etSearchPharmacy.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterMedicines(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        updateCartButton();

        if (btnViewCart != null) {
            btnViewCart.setOnClickListener(v -> {
                if (CartManager.getInstance().getCartItems().isEmpty()) {
                    Toast.makeText(getContext(), "Cart is empty!", Toast.LENGTH_SHORT).show();
                } else {
                    getParentFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, new CartFragment())
                            .addToBackStack(null)
                            .commit();
                }
            });
        }
        return view;
    }

    private void filterMedicines(String text) {
        filteredList.clear();
        for (Medicine item : inventory) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void loadMedicinesFromFirebase() {
        db.collection("Medicines").addSnapshotListener((value, error) -> {
            if (error != null) return;
            if (value != null) {
                inventory.clear();
                for (QueryDocumentSnapshot doc : value) {
                    String name = doc.getString("name");
                    Double price = doc.getDouble("price");
                    if (name != null && price != null) {
                        inventory.add(new Medicine(name, price));
                    }
                }
                filterMedicines(etSearchPharmacy.getText().toString());
            }
        });
    }

    private void updateCartButton() {
        if (btnViewCart != null) {
            int items = CartManager.getInstance().getCartItems().size();
            btnViewCart.setText("View Cart (" + items + " items)");
        }
    }

    public class PharmacyAdapter extends RecyclerView.Adapter<PharmacyAdapter.ViewHolder> {
        private List<Medicine> medicineList;

        public PharmacyAdapter(List<Medicine> medicineList) {
            this.medicineList = medicineList;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_medicine, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Medicine med = medicineList.get(position);
            holder.tvMedName.setText(med.getName());
            holder.tvMedPrice.setText("৳ " + med.getPrice());
            holder.tvQuantity.setText(String.valueOf(med.getQuantity()));

            // --- DYNAMIC IMAGE LOGIC ---
            String medName = med.getName().toLowerCase();
            if (medName.contains("tab") || medName.contains("tablet")) {
                holder.ivMedicineIcon.setImageResource(R.drawable.ic_tablet);
            } else if (medName.contains("inj") || medName.contains("injection")) {
                holder.ivMedicineIcon.setImageResource(R.drawable.ic_injection);
            } else if (medName.contains("sup") || medName.contains("suppositor")) {
                holder.ivMedicineIcon.setImageResource(R.drawable.ic_suppository);
            } else if (medName.contains("syr") || medName.contains("syrup")) {
                holder.ivMedicineIcon.setImageResource(R.drawable.ic_syrup);
            } else {
                holder.ivMedicineIcon.setImageResource(R.drawable.ic_default_medicine); // Keep a default placeholder
            }

            holder.btnPlus.setOnClickListener(v -> {
                med.setQuantity(med.getQuantity() + 1);
                holder.tvQuantity.setText(String.valueOf(med.getQuantity()));
            });

            holder.btnMinus.setOnClickListener(v -> {
                if (med.getQuantity() > 1) {
                    med.setQuantity(med.getQuantity() - 1);
                    holder.tvQuantity.setText(String.valueOf(med.getQuantity()));
                }
            });

            holder.btnAddToCart.setOnClickListener(v -> {
                // FIX: Create a unique instance for the cart to preserve quantity
                Medicine cartItem = new Medicine(med.getName(), med.getPrice());
                cartItem.setQuantity(med.getQuantity());

                CartManager.getInstance().addToCart(cartItem);
                Toast.makeText(v.getContext(), med.getQuantity() + "x " + med.getName() + " added!", Toast.LENGTH_SHORT).show();

                med.setQuantity(1); // Reset local UI quantity
                holder.tvQuantity.setText("1");
                updateCartButton();
            });
        }

        @Override
        public int getItemCount() { return medicineList.size(); }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvMedName, tvMedPrice, tvQuantity;
            Button btnAddToCart;
            ImageButton btnPlus, btnMinus;
            ImageView ivMedicineIcon; // NEW: Added the ImageView

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvMedName = itemView.findViewById(R.id.tvMedName);
                tvMedPrice = itemView.findViewById(R.id.tvMedPrice);
                btnAddToCart = itemView.findViewById(R.id.btnAddToCart);
                tvQuantity = itemView.findViewById(R.id.tvQuantity);
                btnPlus = itemView.findViewById(R.id.btnPlus);
                btnMinus = itemView.findViewById(R.id.btnMinus);

                // NEW: Bind the ImageView from the layout
                // (Make sure your item_medicine.xml has an ImageView with this ID!)
                ivMedicineIcon = itemView.findViewById(R.id.ivMedicineIcon);
            }
        }
    }
}