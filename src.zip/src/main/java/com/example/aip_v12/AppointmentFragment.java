package com.example.aip_v12;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AppointmentFragment extends Fragment {

    private Spinner spinnerDoctors;
    private Button btnPickDate, btnBookAppointment;
    private TextView tvSelectedDateTime;

    // NEW: Patient Input Fields
    private EditText etPatientName, etPatientPhone;

    private String selectedDate = "";
    private String selectedTime = "";

    private FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_appointment, container, false);

        db = FirebaseFirestore.getInstance();

        spinnerDoctors = view.findViewById(R.id.spinnerDoctors);
        btnPickDate = view.findViewById(R.id.btnPickDate);
        btnBookAppointment = view.findViewById(R.id.btnBookAppointment);
        tvSelectedDateTime = view.findViewById(R.id.tvSelectedDateTime);

        // Initialize new fields
        etPatientName = view.findViewById(R.id.etPatientName);
        etPatientPhone = view.findViewById(R.id.etPatientPhone);

        fetchDoctorsFromFirestore();

        spinnerDoctors.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Doctor selectedDoctor = (Doctor) parent.getItemAtPosition(position);
                selectedTime = selectedDoctor.getAvailableTime();
                updateDateTimeText();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        btnPickDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), (view1, selectedYear, selectedMonth, selectedDay) -> {
                selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                updateDateTimeText();
            }, year, month, day);
            datePickerDialog.show();
        });

        // UPDATED: Check for Name and Phone, then save!
        btnBookAppointment.setOnClickListener(v -> {
            String patientName = etPatientName.getText().toString().trim();
            String patientPhone = etPatientPhone.getText().toString().trim();

            if (patientName.isEmpty() || patientPhone.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty()) {
                Toast.makeText(getContext(), "Please fill all details and pick a date!", Toast.LENGTH_SHORT).show();
            } else {
                Doctor selectedDoctor = (Doctor) spinnerDoctors.getSelectedItem();
                if (selectedDoctor != null) {

                    java.util.Map<String, Object> appointment = new java.util.HashMap<>();
                    appointment.put("patientName", patientName); // NEW
                    appointment.put("patientPhone", patientPhone); // NEW
                    appointment.put("doctorName", selectedDoctor.getName());
                    appointment.put("date", selectedDate);
                    appointment.put("time", selectedTime);
                    appointment.put("status", "Pending");

                    db.collection("Appointments").add(appointment)
                            .addOnSuccessListener(documentReference -> {
                                if (getContext() != null) {
                                    Toast.makeText(getContext(), "Appointment Saved to Database!", Toast.LENGTH_LONG).show();
                                    etPatientName.setText(""); // Clear fields after booking
                                    etPatientPhone.setText("");
                                }
                            })
                            .addOnFailureListener(e -> {
                                if (getContext() != null) {
                                    Toast.makeText(getContext(), "Error saving: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            });
                }
            }
        });

        return view;
    }

    private void fetchDoctorsFromFirestore() {
        db.collection("Doctors").get().addOnSuccessListener(queryDocumentSnapshots -> {
            List<Doctor> liveDoctors = new ArrayList<>();
            for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                liveDoctors.add(new Doctor(
                        doc.getId(),
                        doc.getString("name"),
                        doc.getString("specialty"),
                        doc.getString("availableTime"),
                        doc.getDouble("rating")
                ));
            }

            if (getContext() != null) {
                ArrayAdapter<Doctor> adapter = new ArrayAdapter<>(getContext(),
                        android.R.layout.simple_spinner_dropdown_item, liveDoctors);
                spinnerDoctors.setAdapter(adapter);
            }
        }).addOnFailureListener(e ->
                Toast.makeText(getContext(), "Error loading doctors: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void updateDateTimeText() {
        if (!selectedDate.isEmpty() && !selectedTime.isEmpty()) {
            tvSelectedDateTime.setText("Locked Schedule: " + selectedDate + " at " + selectedTime);
        } else if (!selectedTime.isEmpty()) {
            tvSelectedDateTime.setText("Locked Time: " + selectedTime + " (Pick a date)");
        }
    }
}