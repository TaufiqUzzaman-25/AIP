package com.example.aip_v12;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminAddMedicineActivity extends AppCompatActivity {

    private EditText etMedName, etMedPrice;
    private Button btnSaveMedicine;
    private ListView listMedicines;
    private FirebaseFirestore db;

    private List<Medicine> medicineList = new ArrayList<>();
    private ArrayAdapter<Medicine> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_medicine);

        db = FirebaseFirestore.getInstance();

        etMedName = findViewById(R.id.etMedName);
        etMedPrice = findViewById(R.id.etMedPrice);
        btnSaveMedicine = findViewById(R.id.btnSaveMedicine);
        listMedicines = findViewById(R.id.listMedicines);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, medicineList);
        listMedicines.setAdapter(adapter);

        btnSaveMedicine.setOnClickListener(v -> saveMedicineToFirebase());

        // NEW: Long Press to Delete
        listMedicines.setOnItemLongClickListener((parent, view, position, id) -> {
            Medicine med = medicineList.get(position);
            db.collection("Medicines").document(med.getId()).delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, med.getName() + " Deleted", Toast.LENGTH_SHORT).show();
                        fetchMedicines(); // Refresh the list
                    });
            return true;
        });

        fetchMedicines();
    }

    private void fetchMedicines() {
        db.collection("Medicines").get().addOnSuccessListener(queryDocumentSnapshots -> {
            medicineList.clear();
            for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                medicineList.add(new Medicine(
                        doc.getId(),
                        doc.getString("name"),
                        doc.getDouble("price")
                ));
            }
            adapter.notifyDataSetChanged();
        });
    }

    private void saveMedicineToFirebase() {
        String name = etMedName.getText().toString().trim();
        String priceStr = etMedPrice.getText().toString().trim();

        if (name.isEmpty() || priceStr.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double price = Double.parseDouble(priceStr);

        Map<String, Object> medicine = new HashMap<>();
        medicine.put("name", name);
        medicine.put("price", price);

        db.collection("Medicines").add(medicine)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Medicine Added!", Toast.LENGTH_SHORT).show();
                    etMedName.setText("");
                    etMedPrice.setText("");
                    fetchMedicines(); // Refresh the list instantly
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }
}